# This is intended to be "plagiarized" from test1.py, it will account for added # random whitespace or changing of variable names
# This program adds two numbers
def sums():              
    var1 = 1.5            
    num2 = 6.3            



    # Add two numbers
    summation1 = 0
    if num1 == 1.5:
        summation1 = var1 + num2

    for i in range(0, 10):
        num2 += i

    # Display the sum

    print('The sum of {0} and {1} is {2}'.format(var1, num2, summation1))



    var3 = 3



    num4 = 9

    # Add two numbers        
    summation2 = var3 + num4

    # Display the sum           
    print('The sum of {0} and {1} is these 2 numbers: {2}'.format(var3, num4,     	summation2))

 
sums()

